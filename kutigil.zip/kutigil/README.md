# Kutigıl 📦

Küçük kutuda büyük internet. Tek bir HTML dosyasından oluşan, tarayıcı içinde çalışan, yerleşik arama motorlu minimal bir tarayıcı arayüzü.

**Canlı demo:** `https://KULLANICI_ADIN.github.io/kutigil/` (GitHub Pages'i açtıktan sonra)

## Özellikler

- Çoklu sekme (açma, kapatma, geçiş)
- Geri, ileri, yenile ve ana sayfa düğmeleri
- Hem adres hem arama yapabilen akıllı adres çubuğu
- **Kutigıl Arama:** yerleşik dizinde arama (Türkçe karakter duyarsız, puanlamalı, vurgulamalı)
- Dizine kendi sitelerini ekleme (tarayıcıda `localStorage` ile saklanır)
- DuckDuckGo, Bing, Google, Vikipedi ve YouTube'da tek tıkla arama
- Açık ve koyu tema (sistem ayarını izler)
- Mobil uyumlu arayüz
- Klavye kısayolları: `Ctrl/Cmd + T` yeni sekme, `Ctrl/Cmd + L` adres çubuğuna odaklan

## Kurulum

Derleme adımı ve bağımlılık yoktur.

```bash
git clone https://github.com/KULLANICI_ADIN/kutigil.git
cd kutigil
python3 -m http.server 8000
```

Sonra `http://localhost:8000` adresini aç. `index.html` dosyasını doğrudan çift tıklayıp da açabilirsin.

## GitHub Pages ile yayınlama

1. Repo sayfasında **Settings → Pages** bölümüne gir.
2. **Source** olarak `Deploy from a branch`, dal olarak `main` ve klasör olarak `/ (root)` seç.
3. Birkaç dakika sonra site yukarıdaki canlı demo adresinde açılır.

## Nasıl çalışır?

Arama motoru `index.html` içindeki `BASE` dizisini tarar. Her kayıt `[başlık, adres, açıklama, anahtar kelimeler]` biçimindedir. Kalıcı olarak site eklemek için bu diziye yeni satır ekle.

```js
["Site adı","https://ornek.com","Kısa açıklama.","anahtar kelime listesi"],
```

Sonuçlar başlık, anahtar kelime, açıklama ve adres alanlarına göre puanlanır.

## Bilinen sınırlamalar

- Kutigıl gerçek bir tarayıcı motoru değildir; sayfaları `iframe` içinde gösterir.
- Google, YouTube, GitHub gibi birçok site `X-Frame-Options` veya `Content-Security-Policy` nedeniyle bu şekilde açılmayı engeller. Bu siteler `BLOCKED` listesinde tutulur ve gerçek bir sekmede açılır. Listede olmayan bir site boş görünürse adres çubuğundaki **↗** düğmesini kullan, ardından siteyi `BLOCKED` listesine ekle.
- Arama yalnızca yerleşik dizinde yapılır; tüm interneti taramaz. Gerçek web sonuçları için dış arama düğmelerini kullan.

## Yol haritası

- [ ] Yer imleri
- [ ] Geçmiş sayfası
- [ ] Arama motoru seçimi
- [ ] Sekmeleri sürükleyerek sıralama
- [ ] Dizini JSON dosyasından içe/dışa aktarma

## Katkıda bulunma

Pull request'ler açıktır. Büyük değişiklikler için önce bir issue açıp ne yapmak istediğini anlat. Dizine site eklemek için `BASE` dizisine satır eklemen yeterli.

## Lisans

[MIT](LICENSE)
